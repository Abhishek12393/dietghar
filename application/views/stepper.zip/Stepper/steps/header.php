<!DOCTYPE html>
<html lang="en" class="dark-theme">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link href="<?=base_url('stepper_assets/')?>css/pace.min.css" rel="stylesheet" />
<script src="<?=base_url('stepper_assets/')?>js/pace.min.js"></script>
<link href="<?=base_url('stepper_assets/')?>plugins/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet" />
<link href="<?=base_url('stepper_assets/')?>plugins/simplebar/css/simplebar.css" rel="stylesheet" />
<link href="<?=base_url('stepper_assets/')?>plugins/metismenu/css/metisMenu.min.css" rel="stylesheet" />
<link href="<?=base_url('stepper_assets/')?>plugins/datetimepicker/css/classic.css" rel="stylesheet" />
<link href="<?=base_url('stepper_assets/')?>plugins/datetimepicker/css/classic.time.css" rel="stylesheet" />
<link href="<?=base_url('stepper_assets/')?>plugins/datetimepicker/css/classic.date.css" rel="stylesheet" />
<link rel="stylesheet" href="<?=base_url('stepper_assets/')?>plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.min.css" />
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons" />
<link href="<?=base_url('stepper_assets/')?>css/bootstrap.min.css" rel="stylesheet" />
<link href="<?=base_url('stepper_assets/')?>css/bootstrap-extended.css" rel="stylesheet" />
<link href="<?=base_url('stepper_assets/')?>css/style.css" rel="stylesheet" />
<link href="<?=base_url('stepper_assets/')?>css/icons.css" rel="stylesheet" />
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet" />
<link href="<?=base_url('stepper_assets/')?>css/dark-theme.css" rel="stylesheet" />
<link href="<?=base_url('stepper_assets/')?>css/semi-dark.css" rel="stylesheet" />
<link href="<?=base_url('stepper_assets/')?>css/header-colors.css" rel="stylesheet" />
<title>DietGhar Register</title>
<script type="text/javascript">var baseURL= '<?=base_url()?>';</script>
</head>
<style>
.inputs input {width: 40px;height: 40px;}
input[type="number"]::-webkit-inner-spin-button,
input[type="number"]::-webkit-outer-spin-button {-webkit-appearance: none;-moz-appearance: none;appearance: none;margin: 0;}
.form-control:focus {box-shadow: none;border: 2px solid green;}
.validate {border-radius: 20px;height: 40px;background-color: green;border: 1px solid green;width: 140px;}
.align-items-center{-webkit-box-align:center!important;-webkit-align-items:center!important;-ms-flex-align:center!important;align-items:center!important}
  .dnone {
    display: none;
  }
</style>
<body>    