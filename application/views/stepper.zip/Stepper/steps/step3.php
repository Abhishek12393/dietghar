<?php $this->load->view('Stepper/steps/header') ; ?>
<style>
    .inputs input {
        width: 40px;
        height: 40px;
    }
    input[type="number"]::-webkit-inner-spin-button,
    input[type="number"]::-webkit-outer-spin-button {
        -webkit-appearance: none;
        -moz-appearance: none;
        appearance: none;
        margin: 0;
    }
    .form-control:focus {
        box-shadow: none;
        border: 2px solid green;
    }
    td {
        color: whitesmoke;
    }
    button {
        color: whitesmoke;
    }
    .validate {
        border-radius: 20px;
        height: 40px;
        background-color: green;
        border: 1px solid green;
        width: 140px;
    }
  .align-items-center{-webkit-box-align:center!important;-webkit-align-items:center!important;-ms-flex-align:center!important;align-items:center!important}
  .cardpad {width: 30rem;}
  @media screen and (max-width: 600px) {
  .cardpad {width: 25rem;}
}
</style>
<div>
  <br /><br />
  <div class="mb-4 d-flex flex-column gap-3 align-items-center justify-content-center">
      <div class="user-change-photo shadow">
          <img src="https://scontent.fdel3-5.fna.fbcdn.net/v/t1.6435-9/144652277_1191521077912539_5377575342016850392_n.png?_nc_cat=111&ccb=1-7&_nc_sid=09cbfe&_nc_ohc=ZSsbdm9OnD0AX-R6EDF&_nc_ht=scontent.fdel3-5.fna&oh=00_AT8EeCXcEOhpLfJHiG2Ytl5zr89YGHzojpzm8POyAx_IAA&oe=62DC02F1" alt="..." />
      </div>
  </div>
  <center>
    <div class="card align-items cardpad" >
      <form name="myform" id="form_id" method="post" action="<?=base_url('Stepper/stepper_4')?>">
        <div class="card-body d-flex flex-column gap-2 align-items-center justify-content-center">
            <h4 class="mb-0">Date of Birth</h4>
            <br />
            <div class="row gy-3 align-items-center justify-content-center">
                <input class="result form-control" type="text" id="date" placeholder="Select DOB..." data-dtp="dtp_HUqgC" required>
                <span class="error" id="sp" style="display: none">age should be in between 18 to 65 years</span>
            </div>
          <div class="mt-4">
            <h4 class="title-label" id="sp1" ></h4>
            <button class="btn btn-danger px-4 validate" style="display: none;" type="button" id="next" >Next</button>
          </div>
        </div>
      </form>
    </div>
  </center>
</div>
  <?php $this->load->view('Stepper/steps/footer') ; ?>
  <script>
  // defines
  var input = document.getElementById('date');
  document.addEventListener("DOMContentLoaded", function(event) {
    // alert('content loaded');
        $('#date').bootstrapMaterialDatePicker({
            time: false,
            format: 'DD-MM-YYYY',
            closeOnDateSelect: true,
        }).on('change', function(e) {
          document.getElementById("next").style.display="block"; 
        }) ; 
  });
  // bind click handler 
  var clickHandler = ('ontouchstart' in document.documentElement ? "touchstart" : "click");
		$("#next").bind(clickHandler, function(e) {
    	// alert("clicked or tapped. This button used: " + clickHandler);
    	// updatedatacheck();
			console.log(input.value);
      if(input.value == '' || input.value == null){
        console.log('blank val');
      }else{
       updatedob(input.value);
      }
		});
  function updatedob(newdate){
			$.ajax({
					url:  baseURL + 'Diet/checkdob',
					type: 'POST',
					data: {value:newdate},
					error: function() {
						alert('Something is wrong');
					},
					success: function(data) {
						console.log(data)
						$("#sp1").html(data);
						setTimeout(function(){
							$.ajax({
								url:  baseURL + 'Diet/Update',
								type: 'POST',
								data: {table: 'customers_info',column:'dob',value:newdate,where:'id',button:'stepper_4'},
								error: function() {
									alert('Something is wrong');
								},
								success: function(data) {
									$("#form_id").submit();
								}
							});
						}, 3000);
					}
				});
		}

  </script>
</html>