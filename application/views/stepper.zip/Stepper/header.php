<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Dietghar</title>
<script type="text/javascript">var baseURL= '<?=base_url()?>';</script>
<?php $tt=date("s"); ?>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet"> 
<link rel="stylesheet" href="<?php echo base_url(); ?>dgassets/stepper/stylesheet.css?v=<?php echo $tt; ?>">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-1.7.2.min.js"></script>
<style>
#next{display:none;}
.down {margin-top:0px;}
#bgbdy {background-image: url(<?php echo base_url(); ?>dgassets/stepper/bg-desktop.jpg);background-repeat: no-repeat;background-size: cover;}
@media only screen and (max-width: 1600px) {#bgbdy {background-image: url('<?php echo base_url(); ?>dgassets/stepper/bg-desktop.jpg'); width:100%; height:92vh;}}
@media only screen and (max-width: 1200px) {#bgbdy {background-image: url('<?php echo base_url(); ?>dgassets/stepper/bg-desktop.jpg'); width:100%; height:92vh;}}
@media only screen and (max-width: 575px) {#bgbdy {background-image: url('<?php echo base_url(); ?>dgassets/stepper/bg-mobile.jpg'); width:100%; height:92vh;}}
@media (min-width:360px) and (max-width:800px) and  (orientation:landscape) {#turn{display:block;}#containerz{display:none;}}
@media (min-width:360px) and (max-width:800px) and (orientation:portrait){#turn{display:none;}#containerz{display:block;}}
@media (min-width:768px) and (max-width:1920px) and (orientation:landscape){#turn{display:none;}#containerz{display:block;}}
@media (min-width:768px) and (max-width:1920px) and  (orientation:portrait) {#turn{display:block;}#containerz{display:none;}}
@media all and (device-width: 768px) and (device-height: 1024px) and (orientation:portrait) {#turn{display:none;}#containerz{display:block;}
#bgbdy {background-image: url('<?php echo base_url(); ?>dgassets/stepper/bg-mobile.jpg'); width:100%; height:82vh;}}
@media all and (device-width: 768px) and (device-height: 1024px) and (orientation:landscape) {#turn{display:block;}#containerz{display:none;}}
</style>
<!--<script type="text/javascript">function res() { document.write(screen.width + ', ' + screen.height); }res();</script>-->
<title>Dietghar Login </title>
</head>
<body id="bgbdy">
<header id="masthead" class="header ttm-header-style-classic">
<div class="ttm-header-wrap">
<div id="ttm-stickable-header-w" class="ttm-stickable-header-w clearfix">
<div id="site-header-menu" class="site-header-menu">
<div class="site-header-menu-inner ttm-stickable-header">
<div class="container">
<div class="site-branding" style="float: none;height: 115px;line-height: 115px;position: relative;display: block;z-index: 1;text-align: center;">
<a class="home-link" href="https://dietghar.com" title="Dietghar" rel="home">
<img id="logo-img" class="img-center" src="<?php echo base_url(); ?>diet/assets/images/logo-diet.png" alt="logo-img">
</a>
</div>
</div>
</div>
</div>
</div>
</div>
</header>
<div id="turn"><br /><br /><center>Please rotate your device!</center></div>
<div id="containerz">