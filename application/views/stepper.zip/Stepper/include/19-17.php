<script>
function workout(event,val)
{
event.preventDefault();
updateDatas('user_id','customer_lifestyle','workout_follow',val,'stepper_20/18');
}
</script>