<script>
function thtype(event)
{
var val= $("#thyroid").val();
event.preventDefault();
updateDatas('user_id','customer_lifestyle','thyroid',val,'stepper_22/20');
}
</script>