<script>
function dbtype(event)
{
var val = $("#diabetes").val();
event.preventDefault();
updateDatas('user_id','customer_lifestyle','diabetes',val,'stepper_24/18');
}
</script>