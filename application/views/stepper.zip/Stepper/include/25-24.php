<script>
function blood(event,val)
{
event.preventDefault();
updateDatas('user_id','customer_lifestyle','bp',val,'stepper_27/25');
}
</script>